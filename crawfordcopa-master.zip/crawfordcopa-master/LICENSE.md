# License
The content of this project itself is licensed under the Creative Commons Attribution-NonCommercial 4.0 International license. See CC.html. 
The underlying source code used to format and display that content is licensed under the GNU GENERAL PUBLIC LICENSE
Version 3. See COPYING file for the full license.